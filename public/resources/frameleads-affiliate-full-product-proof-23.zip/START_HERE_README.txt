FRAMELEADS — AFFILIATE PRODUCT PROOF LIBRARY
November 2026 | 23 authentic UI screenshots

WHAT THIS IS
A library of real FrameLeads interface screenshots captured in a demo/test
context. Prospects, messages, monetary amounts, intent scores and business
names shown in examples are illustrative; they do NOT establish customer
results, real revenue, conversion rates or guaranteed outcomes.

WHERE TO START — 01_START_HERE_INBOX_TRIAGE
FrameLeads' core differentiation is helping founder-led B2B agencies decide
what happens AFTER a prospect replies. If creating just one post/video,
start with this 4-frame narrative:
  01 Incoming Replies — actual reply enters the decision queue
  02 Intent Signals — interest and context are presented for interpretation
  03 Decision Packet — why a commercial exception requires human review
  04 Inbox Overview — the workflow at a glance

FULL FREEDOM — 02_FULL_PRODUCT_WORKFLOW
Additional screenshots cover Lead Ingestion, Scout, Campaign Configuration,
Outbound Sandbox, Decision Sandbox, Deployment, Governance and Outcome Learning.
They are optional supporting views; you do not have to show every feature.

HOW PARTNERS MAY USE THIS
- Explain features using these real UI screenshots, including in videos,
  comparison posts, social content or educational content.
- Crop, annotate or resize for legibility, but preserve context and avoid
  making altered screenshots look like actual product output.
- Use the partner's own product-specific referral links from their Whop
  dashboard. A generic URL may not track an affiliate's commissions.
- Read current partner rules in Whop; they can change over time.
- Future approved product video clips will be added separately.

WHAT NOT TO CLAIM
- Do not imply samples depict paying customers or real customer revenue.
- Do not state that an intent score is a probability of closing.
- Do not claim guaranteed deals, profit, 100% reply accuracy or autonomous
  approval/sending of consequential replies.
- Do not claim a sandbox, mock or setup screen proves a feature is live for
  every subscription, or that commercial exceptions are auto-approved.
- Do not invent user testimonials, performance claims, or before/after stats.

SUGGESTED WORDING
"Outbound tools help send messages. FrameLeads helps teams review replies,
understand intent and decide the next action—with human approval where it
matters. These are real product screens shown with illustrative demo data."

© 2026 FrameLeads / BrandFlow Studio. Shared for affiliate product education.
